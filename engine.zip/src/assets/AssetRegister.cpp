#include "axelpch.h"
#include "AssetRegister.h"
#include <yaml-cpp/yaml.h>
#include <fstream>

#include "Serialisation/Archive.h"

struct Axel::AssetRegister::RegistryImpl {
    std::unordered_map<Axel::UUID, AssetMetadata> Data;
};

const Axel::AssetMetadata& Axel::AssetRegister::GetMetadata(UUID id) const
{
    static const AssetMetadata s_Empty{};
    auto it = m_Registry.find(id);
    return (it != m_Registry.end()) ? it->second : s_Empty;
}

void Axel::AssetRegister::Serialize(IArchive& ar)
{
    if (ar.BeginStruct("AssetRegister"))
    {

        if (ar.GetMode() == ArchiveModeOptions::Save)
        {
            m_AssetCount = (uint32_t)m_Registry.size();
            ar.Property("AssetCount", m_AssetCount);
            if (ar.BeginCollection("Assets", m_AssetCount))
            {
                for (auto& [id, metadata] : m_Registry)
                {
                    metadata.Serialize(ar);
                    ar.NextItem();
                }
                ar.EndCollection();
            }
        }
        else
        {
            m_Registry.clear(); // Fresh start for the address book
            ar.Property("AssetCount", m_AssetCount);
            if (ar.BeginCollection("Assets", m_AssetCount))
            {
                while(ar.HasNext())
                {
                    AssetMetadata metadata;
                    metadata.Serialize(ar);
                    m_Registry[metadata.AssetID] = metadata; // Use the deserialized ID as the key
                    ar.NextItem();
                }
                ar.EndCollection();
            }
        }
   
        ar.EndStruct();        
    }
}

void Axel::AssetMetadata::Serialize(IArchive& ar) 
{
	int typeVal = (int)AssetType;
    if (ar.BeginStruct(""))
    {
        ar.Property("ID", AssetID);
        ar.Property("Name", Name);
        ar.Property("Path", Path);
        ar.Property("Type", typeVal);

        // 3. THE CRITICAL STEP: Re-assign back to the class during Load
        if (ar.GetMode() == ArchiveModeOptions::Load)
        {
            AssetType = (AssetTypeOptions)typeVal;
        }

        ar.EndStruct();
    }
}