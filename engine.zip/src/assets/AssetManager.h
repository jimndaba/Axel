#pragma once
#ifndef ASSETMANAGER_H
#define ASSETMANAGER_H

#include <core/Logger.h>
#include "AssetRegister.h"
#include <rendering/Shader.h>
#include <rendering/Texture.h>
#include <scene/Scene.h>
#include <rendering/MaterialTemplate.h>
#include "Loaders/TextureLoader.h"
#include "Loaders/Sceneloader.h"
#include <rendering/GraphicsDevice.h>

namespace Axel
{
    class Shader; 

	class AX_API  AssetManager
	{
    public:
        AssetManager(GraphicsDevice* device);
        // The main "Request" function

        // Called on Engine Init
        void Initialize(const std::string& projectFile);

		static void Shutdown() { 
            s_Instance->m_Registry.Clear();
            s_Instance->m_LoadedAssets.clear();
        }
	
        static void Clear() { 
            s_Instance->m_Registry.Clear();
            s_Instance->m_LoadedAssets.clear();
            AXLOG_TRACE("Asset Register Cleared");
        }
        static void RegisterAsset(AssetMetadata& meta);
        static void RegisterAsset(AssetMetadata& meta,const Ref<IAsset>& asset);

        static AssetMetadata GetAssetMetadata(UUID id) { return s_Instance->m_Registry.GetMetadata(id); }

        template<typename T>
        static Ref<T> GetAsset(UUID id) {
            return s_Instance->GetAssetInternal<T>(id);           
        }

        template<typename T>
        static Ref<T> GetAssetByName(const std::string& name) {
            return s_Instance->GetAssetByNameInternal<T>(name);
        }
        template<typename T>
        static void RegisterAsset(Ref<T> asset)
        {
            s_Instance->RegisterAssetInternal<T>(asset);
        }

        static UUID GetAssetIDByName(const std::string& name);

        static void SetAssetFilePath(const std::string& path) { s_Instance->SetAssetFilePathInternal(path); }
        static void SaveRegistry();
		static void LoadRegistry();

        AssetRegister& GetRegister() { return m_Registry; }

        static bool HasAsset(const std::string& name);
        static bool HasAsset(UUID id);

        static std::string& GetAssetFolderPath();
        
        static std::string GetMaterialsFileExtension() {return ".axMaterial";}
     
    private:

        GraphicsDevice* m_Device  = nullptr;
        static AssetManager* s_Instance; // The only static part

        template<typename T>
        Ref<T> GetAssetInternal(UUID id) {
            // 1. Check if it's already in memory
            if (m_LoadedAssets.find(id) != m_LoadedAssets.end()) {
                return std::static_pointer_cast<T>(m_LoadedAssets[id]);
            }

            // 2. Not in memory, find where it is on disk via the Registry
            const AssetMetadata& metadata = m_Registry.GetMetadata(id);
            if (metadata.AssetType == AssetTypeOptions::None) return nullptr;

            // 3. Load it based on type
            Ref<IAsset> asset = nullptr;
            if (!metadata.IsValid()) return nullptr;// Sanity check

            switch (metadata.AssetType) {
            case AssetTypeOptions::Texture2D:
                asset = std::static_pointer_cast<IAsset>(TextureLoader::Load(metadata.Path));
                break;
            case AssetTypeOptions::Shader:
                asset = std::static_pointer_cast<IAsset>(Shader::Create(*m_Device, metadata.Path));
                break;
            case AssetTypeOptions::MaterialTemplate:
                //asset = std::static_pointer_cast<IAsset>(MaterialTemplateLoader::Load(metadata.Path));
                break;
            case AssetTypeOptions::Scene:
                asset = std::static_pointer_cast<IAsset>(SceneLoader::LoadScene(metadata.Path));
                break;
            }

            if (asset) {
                asset->AssetID = id;
                m_LoadedAssets[id] = asset;
                return std::static_pointer_cast<T>(asset);
            }

            if (metadata.AssetType == AssetTypeOptions::Shader) {
                auto shader = Shader::Create(*m_Device, metadata.Path);
                asset = std::static_pointer_cast<IAsset>(shader);
            }
            return std::static_pointer_cast<T>(asset);
        }

        template<typename T>
        Ref<T> GetAssetByNameInternal(const std::string& name) {
            // 1. Ask the registry to find the UUID associated with this name
            // Assuming your AssetRegister has a GetUUIDByName method
            UUID id = m_Registry.GetUUIDByName(name);

            // 2. If the UUID is null/invalid, the asset doesn't exist in the registry
            // 3. Reuse the existing UUID-based logic (which handles caching and loading)
            return GetAssetInternal<T>(id);
        }

        template<typename T>
        void RegisterAssetInternal(Ref<T> asset)
        {
            static_assert(std::is_base_of<IAsset, T>::value, "RegisterAsset only accepts types derived from IAsset");

            if (!asset) {
                AXLOG_ERROR("Attempted to register a null asset!");
                return;
            }

            UUID id = asset->AssetID;

            // Check if it's already there to prevent accidental leaks or logic errors
            if (m_LoadedAssets.find(id) != m_LoadedAssets.end()) {
                AXLOG_WARN("Asset with UUID {0} is already registered. Skipping.", id);
                return;
            }

            // Since m_LoadedAssets stores Ref<IAsset>, 
            // the polymorphism handles the cast automatically.
            m_LoadedAssets[id] = asset;
            AssetMetadata data;
            data.AssetID = id;
            m_Registry.AddAsset(id, data);
        }

		void SetAssetFilePathInternal(const std::string& path) { m_CurrentAssetFile = path; }

		std::string GetAssetFilePathInternal() const { return m_CurrentAssetFile; }

        AssetRegister m_Registry;
        std::unordered_map<UUID, Ref<IAsset>> m_LoadedAssets; // In-memory cache of loaded assets
        std::string m_CurrentAssetFile;
        std::string m_CurrentAssetFolder;
    };	
}


#endif
