#include "axelpch.h"
#include "MeshLoader.h"
#include <assets/Serialisation/YAMLArchive.h>
#include <rendering/MaterialInstance.h>
#include <math/Math.h>
#include <assets/AssetManager.h>



Axel::MeshLoader::MeshLoader()
{
}

template<typename T>
bool Axel::MeshLoader::LoadGLTF(const std::string& path, Mesh<T>& outMesh) {
    cgltf_options options = {};
    cgltf_data* data = nullptr;
    cgltf_result result = cgltf_parse_file(&options, path.c_str(), &data);

    if (result != cgltf_result_success) return false;

    cgltf_load_buffers(&options, data, path.c_str());

    // 1. Iterate through meshes and primitives
    for (size_t i = 0; i < data->meshes_count; ++i) {
        for (size_t j = 0; j < data->meshes[i].primitives_count; ++j) {
            cgltf_primitive& prim = data->meshes[i].primitives[j];

            Submesh sub;
            sub.IndexOffset = static_cast<uint32_t>(outMesh.m_Indices.size());
           
            uint32_t vertexStartForThisPrim = static_cast<uint32_t>(outMesh.m_Vertices.size());
            ExtractAttributes(prim, outMesh);
            ExtractIndices(prim, outMesh, vertexStartForThisPrim);

            sub.IndexCount = static_cast<uint32_t>(outMesh.m_Indices.size()) - sub.IndexOffset;

            // The critical link:
            if (prim.material) {
                // cgltf gives us a pointer; we need to find its index in the global list
                sub.MaterialIndex = (uint32_t)(prim.material - data->materials);
            }
            else {
                sub.MaterialIndex = 0; // Fallback to a default slot
            }

            outMesh.m_Submeshes.push_back(sub);
        }
    }


    // Inside LoadGLTF
    for (size_t i = 0; i < data->materials_count; ++i)
    {
        cgltf_material& gltfMat = data->materials[i];

        // 1. Create your MaterialInstance based on Standard_PBR
        auto instance = GetMaterialIndex(&gltfMat,path);
        // 4. Store in your Mesh's material slot list
        outMesh.m_Materials.push_back(instance);
    }

    cgltf_free(data);
    return true;
}

Axel::UUID Axel::MeshLoader::GetMaterialIndex(cgltf_material* gltfMaterial, const std::string& modelPath) {
    // TODO if (!gltfMaterial) return AssetManager::GetDefaultMaterialID();

    std::string instanceName = gltfMaterial->name ? gltfMaterial->name : "unnamed";

    // Check if instance already exists
    if (AssetManager::HasAsset(instanceName)) {
        return AssetManager::GetAssetIDByName(instanceName);
    }

    // 1. Fetch the Template (e.g., the "Standard_PBR" Template)
    Ref<MaterialTemplate> pbrTemplate = AssetManager::GetAssetByName<MaterialTemplate>("Standard_PBR_Template");

    // 2. Create a Material Instance (The actual data container)
    Ref<MaterialInstance> instance = pbrTemplate->CreateInstance(instanceName);
    
    // 3. Map glTF properties to the Template's Descriptors
    if (gltfMaterial->has_pbr_metallic_roughness) {
        auto& pbr = gltfMaterial->pbr_metallic_roughness;
        // Use the Descriptors to find WHERE to write in the instance buffer
        instance->Set("u_AlbedoColour", Vec4(pbr.base_color_factor[0]));
        instance->Set("u_Metallic", pbr.metallic_factor);
        instance->Set("u_Roughness", pbr.roughness_factor);

        if (pbr.base_color_texture.texture) {
            //TEXTURE LOADING TO DO
            //std::string texPath = ResolveTexturePath(modelPath, pbr.base_color_texture.texture);

            // Load as a formal Texture Asset
            //UUID texID = AssetManager::GetOrCreateTextureAsset(texPath);

            // Set the texture property in the instance
            //instance->Set("u_AlbedoMap", texID);
        }
    }

    std::string asset_folder =  AssetManager::GetAssetFolderPath() +  "/Materials/";
    std::string asset_path = asset_folder + instanceName + AssetManager::GetMaterialsFileExtension();

    AssetMetadata meta;
    meta.AssetID = instance->AssetID;
    meta.AssetType = AssetTypeOptions::Material;
    meta.Name = instanceName;
    meta.Path = asset_path;
    AssetManager::RegisterAsset(meta,instance);

   
    YAMLArchive ar(ArchiveModeOptions::Save, asset_path);
    instance->Serialize(ar);

    return instance->AssetID;
}

template bool Axel::MeshLoader::LoadGLTF<Axel::StaticVertex>(const std::string&, Mesh<StaticVertex>&);
template bool Axel::MeshLoader::LoadGLTF<Axel::SkeletalVertex>(const std::string&, Mesh<SkeletalVertex>&);