#include "axelpch.h"
#include "SceneLoader.h"
#include <scene/Scene.h>
#include <assets/ISerialisable.h>
#include <assets/Serialisation/YAMLArchive.h>

std::shared_ptr<Axel::Scene> Axel::SceneLoader::LoadScene(const std::string& path)
{
    auto scene = std::make_shared<Axel::Scene>();
    Axel::YAMLArchive ar(ArchiveModeOptions::Load,path);
    scene->Serialize(ar);
    return scene;
}
