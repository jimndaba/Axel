#pragma once
#ifndef MESHLOADER_H
#define MESHLOADER_H

#include <rendering/Mesh.h>
#include <core/UUID.h>
#include <cgltf/cgltf.h>


namespace Axel
{
	class MaterialTemplate;
	class MaterialInstance;


	class MeshLoader
	{
	public:

		MeshLoader();
		template<typename T>
		static bool LoadGLTF(const std::string& path, Mesh<T>& outMesh);

	private:
		template<typename T>
		static void ExtractAttributes(cgltf_primitive& prim, Mesh<T>& outMesh);

		template<typename T>
		static void ExtractIndices(cgltf_primitive& prim, Mesh<T>& outMesh, uint32_t vertexStart);

		static Axel::UUID GetMaterialIndex(cgltf_material* gltfMaterial, const std::string& modelPath);


	};

    template<typename T>
    inline void  Axel::MeshLoader::ExtractAttributes(cgltf_primitive& prim, Mesh<T>& outMesh) {
        size_t startVertex = outMesh.m_Vertices.size();
        size_t vertexCount = prim.attributes[0].data->count;

        // Resize the vector to accommodate new vertices
        outMesh.m_Vertices.resize(startVertex + vertexCount);

        for (size_t i = 0; i < prim.attributes_count; ++i) {
            cgltf_attribute& attr = prim.attributes[i];
            cgltf_accessor* accessor = attr.data;

            // This is a helper to get the float pointer regardless of buffer layout
            std::vector<float> buffer(accessor->count * cgltf_num_components(accessor->type));
            cgltf_accessor_unpack_floats(accessor, buffer.data(), buffer.size());

            for (size_t v = 0; v < accessor->count; ++v) {
                T& vertex = outMesh.m_Vertices[startVertex + v];
                float* data = &buffer[v * cgltf_num_components(accessor->type)];

                switch (attr.type) {
                case cgltf_attribute_type_position:
                    vertex.Position = { data[0], data[1], data[2] };
                    break;
                case cgltf_attribute_type_normal:
                    vertex.Normal = { data[0], data[1], data[2] };
                    break;
                case cgltf_attribute_type_texcoord:
                    vertex.TexCoord = { data[0], data[1] };
                    break;
                case cgltf_attribute_type_tangent:
                    vertex.Tangent = { data[0], data[1], data[2] };
                    break;
                case cgltf_attribute_type_color:
                    vertex.VertexColor = { data[0], data[1], data[2], data[3] };
                    break;
                }
            }
        }
    }

	template<typename T>
	inline void Axel::MeshLoader::ExtractIndices(cgltf_primitive& prim, Mesh<T>& outMesh, uint32_t vertexStart)
	{
		if (!prim.indices) return;

		size_t startIndex = vertexStart;
		size_t indexCount = prim.indices->count;

		// Calculate offset based on vertices added by this specific primitive
		uint32_t vertexOffset = static_cast<uint32_t>(outMesh.m_Vertices.size() - prim.attributes[0].data->count);

		outMesh.m_Indices.resize(startIndex + indexCount);

		for (size_t i = 0; i < indexCount; ++i) {
			outMesh.m_Indices[startIndex + i] = static_cast<uint32_t>(cgltf_accessor_read_index(prim.indices, i)) + vertexOffset;
		}
	}






}


#endif